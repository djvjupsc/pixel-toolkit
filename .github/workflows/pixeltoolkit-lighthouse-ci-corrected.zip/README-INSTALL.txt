# PixelToolkit Lighthouse CI (corrected)

This package adds a **separate** Lighthouse workflow. Keep your existing
`.github/workflows/pwa-validation.yml` unchanged.

## Install from Android

1. Extract this ZIP.
2. In GitHub, open `djvupsc/pixel-toolkit`.
3. Open `.github` → `workflows`.
4. Choose **Add file** → **Upload files**.
5. Upload only `lighthouse-audit.yml` from this package.
6. Commit the change to `main`.

The workflow audits `https://pixel-toolkit.pages.dev/` after waiting for the
Cloudflare Pages site to respond. It runs on pushes to `main` or `master`,
and can also be started manually from Actions → PixelToolkit Lighthouse Audit
→ Run workflow.

## Find the report

GitHub → Actions → **PixelToolkit Lighthouse Audit** → latest run.
At the bottom of the run summary, download the artifact:

`pixeltoolkit-lighthouse-reports`

Extract it and open `pixeltoolkit-lighthouse.html` in Chrome. The JSON file
contains the detailed audit data. The workflow also prints the four category
scores in the job log.

## Notes

- This workflow does not change your website files or your PWA validation workflow.
- It audits the live `pages.dev` URL. It does not itself trigger Cloudflare deployment.
- A green workflow run means the audit completed; the scores still need to be reviewed.
- The workflow waits up to 10 minutes for the site to respond. If Cloudflare deployment
  takes longer, rerun the audit manually.
